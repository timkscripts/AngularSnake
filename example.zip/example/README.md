Example application with AngularJS up and running on Node.js & ExpressJS using Bower.io

## Setup

### Install Bower
`npm install -g bower`

### Install Dependencies

```bash
npm install
bower install
```

### Run App

`npm start` then visit <http://localhost:3000>
